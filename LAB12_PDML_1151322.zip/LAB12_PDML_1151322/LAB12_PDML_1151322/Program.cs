﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB12_PDML_1151322
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[,] T = new int[4, 5];
            Random r = new Random();
            int suma = 0;
            double prom = 0;
            for (int i = 0; i < 4; i++)
            {
                for (int x = 0; x < 5; x++)
                {
                    T[i, x] = r.Next(30);
                    suma = suma + T[i, x];
                }
            }
            Console.WriteLine("La suma total de los valores es: " +suma);

            for (int z = 0; z < 4; z++)
            {
                for (int y = 0; y < 5; y++)
                {
                    T[z, y] = r.Next(30);
                    prom = suma/20;
                }
            }
            Console.WriteLine("El promedio total de los valores es: " +prom);

            
            
            //Dos Matrices Iguales 
            Console.WriteLine("Ejercicio 2");
            Console.WriteLine("Suma de dos matrices");


            int[,] t1 = new int[3, 4];
            Random r1 = new Random();
            int sum = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int x = 0; x < 4; x++)
                {
                    t1[i, x] = r1.Next(30);
                }
            }
            int[,] t2 = new int[3, 4];
            Random r2 = new Random();
            for (int i = 0; i < 3; i++)
            {
                for (int x = 0; x < 4; x++)
                {
                    t2[i, x] = r2.Next(30);
                }
            }
            int[,] t3 = new int[3, 4];
            for (int i = 0; i < 3; i++)
            {
                for (int x = 0; x < 4; x++)
                {
                    t3[i, x] = t1[i,x] + t2[i,x];
                }
            }
            for (int i = 0; i < 3; i++)
            {
                for (int x = 0; x < 4; x++)
                {
                    Console.Write(t3[i,x]+"\t");

                }
                Console.WriteLine();
                
            }
            Console.ReadKey();

        }
    }
}
