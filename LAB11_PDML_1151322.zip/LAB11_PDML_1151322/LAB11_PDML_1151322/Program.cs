﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB11_PDML_1151322
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] seccionA = new double[10];
            double[] seccionB = new double[10];
            int numero = 1;
            int numero2 = 1;

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Ingrese la nota del estudiante (Seccion A): " + numero);
                numero++;
                seccionA[i] = double.Parse(Console.ReadLine());
            }
            Console.Clear();
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Ingrese la nota del estudiante (Seccion 2): " + numero2);
                numero2++;
                seccionB[i] = double.Parse(Console.ReadLine());
            }
            Console.Clear();

            int aprobados = 0;
            int Desaprobados = 0;
            for (int i = 0; i < 10; i++)
            {
                if (seccionA[i] >= 65)
                {
                    aprobados = aprobados + 1;
                }
                else
                {
                    Desaprobados = Desaprobados + 1;
                }
            }
            int Promaprobados;
            int Promdesaprobados;
            Promaprobados = (aprobados * 100) / 10;
            Promdesaprobados = (Desaprobados * 100) / 10;
            Console.WriteLine("El % de estudiantes aprobados es de (Seccion A): " + Promaprobados);
            Console.WriteLine("El % de estudiantes desaprobados es de (Seccion A): " + Promdesaprobados);

            int PromaprobadosB = 0;
            int PromdesaprobadosB = 0;
            for (int i = 0; i < 10; i++)
            {
                if (seccionB[i] >= 65)
                {
                    PromaprobadosB = PromaprobadosB + 1;
                }
                else
                {
                    PromdesaprobadosB = PromdesaprobadosB + 1;
                }
            }
            int pPaprobados2;
            int pPdesaprobados2;
            pPaprobados2 = (PromaprobadosB * 100) / 10;
            pPdesaprobados2 = (PromdesaprobadosB * 100) / 10;
            Console.WriteLine("El % de alumnos aprobados es de (Seccion B): " + pPaprobados2);
            Console.WriteLine("El % de alumno desaprobados es de (Seccion B): " + pPdesaprobados2);

            int aprobados1raA = 0;
            int aprobados1raB = 0;
            int sumaaprobadosAyB = 0;
            for (int i = 0; i < 10; i++)
            {
                if (seccionA[i] >= 65)
                {
                    aprobados1raA = aprobados1raA + 1;
                    if (seccionB[i] >= 65)
                    {
                        aprobados1raB = aprobados1raB + 1;
                        sumaaprobadosAyB = aprobados1raB + aprobados1raA;

                    }
                }
            }
            int Psumaprobados1y2 = (sumaaprobadosAyB * 100) / 20;

            //porcentaje aprobado sec B
            Console.WriteLine("El % de alumnos aprobados por las 2 secciones es: " + Psumaprobados1y2); 
            int desaprobados1raA = 0;
            int desaaprobados1raB = 0;
            int sumadesaprobadosAyB = 0;
            for (int i = 0; i < 10; i++)
            {
                if (seccionA[i] < 65)
                {
                    desaprobados1raA = desaprobados1raA + 1;
                    if (seccionB[i] < 65)
                    {
                        desaaprobados1raB = desaaprobados1raB + 1;
                        sumadesaprobadosAyB = desaaprobados1raB + desaprobados1raA;

                    }
                }
            }
            int PsumadesaprobadosAyB = (sumadesaprobadosAyB * 100) / 20;
            Console.WriteLine("El % de alumnos desaprobados por las 2 secciones es de: " + PsumadesaprobadosAyB); // porcentaje desaprobado 2 sec

            double sumanotassecA = 0;
            double promediosecA = 0;
            for (int i = 0; i < 10; i++)
            {
                sumanotassecA = (seccionA[i] + sumanotassecA);
                promediosecA = sumanotassecA / 10;
            }
            Console.WriteLine("El promedio de notas de la seccion 1 es: " + promediosecA);
            double sumanotassecB = 0;
            double promediosecB = 0;
            for (int i = 0; i < 10; i++)
            {
                sumanotassecB = (seccionB[i] + sumanotassecB);
                promediosecB = sumanotassecB / 10;
            }
            Console.WriteLine("El promedio de notas de la seccion 2 es: " + promediosecB);

            double notas1 = 0; // promedio de las 2 secciones 
            double notas2 = 0;
            double sumanotas1y2sec = 0;
            for (int i = 0; i < 10; i++)
            {
                if (seccionA[i] >= 0)
                {
                    notas1 = (seccionA[i] + notas1);
                    if (seccionB[i] >= 0)
                    {
                        notas2 = (seccionB[i] + notas2);
                    }
                }
            }
            sumanotas1y2sec = notas1 + notas2;
            double Promsumanotas1y2sec = sumanotas1y2sec / 20;
            Console.WriteLine("El promedio de notas de las 2 secciones es: " + Promsumanotas1y2sec); //muestra promedio de las 2 secciones
            
            // cantidad de estudiantes con nota mayor a 90
            int cEstM901 = 0;
            int cEstM902 = 0;
            int cEstM903 = 0;
            for (int i = 0; i < 10; i++)
            {
                if (seccionA[i] > 90)
                {
                    cEstM901 = cEstM901 + 1;
                    if (seccionB[i] > 90)
                    {
                        cEstM902 = cEstM902 + 1;
                    }
                }
            }
            cEstM903 = (cEstM901 + cEstM902);
            Console.WriteLine("Cantidad de estudiantes con promedio mayor a 90: " + cEstM903); // muestra cantidad de estudiante con promedio mayor a 90

            int cEstM9751 = 0;
            int cEstM9752 = 0;
            int cEstM9753 = 0;
            for (int i = 0; i < 10; i++)
            {
                if (seccionA[i] < 75)
                {
                    cEstM9751 = cEstM9751 + 1;
                    if (seccionB[i] < 75)
                    {
                        cEstM9752 = cEstM9752 + 1;
                    }
                }
            }
            cEstM9753 = (cEstM9751 + cEstM9752);
            Console.WriteLine("Cantidad de estudiantes con promedio menor a 75: " + cEstM9753); // muestra cantidad de estudiante con promedio menor a 75
            Console.ReadKey();
        }
    }
}
