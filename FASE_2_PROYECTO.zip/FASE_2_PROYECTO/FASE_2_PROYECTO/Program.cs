﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace FASE_2_PROYECTO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.BackgroundColor = ConsoleColor.DarkBlue;

            string nombre;
            Console.WriteLine("Sistema de automitizacion del hogar, quien entrara al sistema");
            nombre = Console.ReadLine();
            Console.Clear();
        menu:
            Console.Clear();
            int opciones = 0;
            Console.WriteLine("       Bienvenido al sistema de automatizacion " + nombre);
            Console.WriteLine("       Ingrese entre las opciones");
            Console.WriteLine("       1. Ventilacion");
            Console.WriteLine("       2. Calefaccion");
            Console.WriteLine("       3. Iluminacion");
            Console.WriteLine("       4. Panel de Control");
            Console.WriteLine("       5. Salir ");
            opciones = int.Parse(Console.ReadLine());

            switch (opciones)
            {
                case 1:
                    Console.Clear();
                    Console.WriteLine("---------------------------------------------------------------");
                    Console.WriteLine("Esta desabilitada esta opcion");
                    Console.WriteLine("---------------------------------------------------------------");
                    Console.WriteLine("Prescione enter para regresar");
                    Console.WriteLine("---------------------------------------------------------------");

                    Console.ReadKey();
                    goto menu;
                    break;
                case 2:
                    Console.Clear();
                    Console.WriteLine("---------------------------------------------------------------");
                    Console.WriteLine("Esta desabilitada esta opcion");
                    Console.WriteLine("---------------------------------------------------------------");
                    Console.WriteLine("Prescione enter para regresar");
                    Console.WriteLine("---------------------------------------------------------------");

                    Console.ReadKey();
                    goto menu;
                    break;
                case 3:
                    Console.Clear();
                    Console.WriteLine("---------------------------------------------------------------");
                    Console.WriteLine("Esta desabilitada esta opcion");
                    Console.WriteLine("---------------------------------------------------------------");
                    Console.WriteLine("Prescione enter para regresar");
                    Console.WriteLine("---------------------------------------------------------------");

                    Console.ReadKey();
                    goto menu;
                case 4:
                    Console.Clear();
                    Console.WriteLine("Bienvenido al panel de control");

                    int opcion = 0;
                menus:
                    Console.Clear();
                    Console.WriteLine("       Opciones de configuracion");
                    Console.WriteLine("       1. Horario de ventilacion");
                    Console.WriteLine("       2. Temperatura maxima y minima");
                    Console.WriteLine("       3. Promedio de temperatura");
                    Console.WriteLine("       4. Regresar al menu principal");

                    opcion = int.Parse(Console.ReadLine());

                    switch (opcion)
                    {
                        case 1:
                            Console.Clear();
                            int aleatorio;
                            int i = 0;
                            int hor;
                            int minutos;
                            int h = 0;
                            int apagado;
                            int encendido;
                            Console.WriteLine("Programar las horas de encendido y de apagado");
                            Console.WriteLine("Ingresar las horas de apagado");
                            apagado = int.Parse(Console.ReadLine());
                            Console.WriteLine("Ingresar las horas de encendido");
                            encendido = int.Parse(Console.ReadLine());
                            Console.Clear();
                            Console.ReadKey();
                            Console.WriteLine("Bienvenido al sistema de ventilacion");
                            Console.WriteLine("De primero colocara las horas y luego los minutos");
                            Console.WriteLine("Ingrese las horas");
                            hor = Int32.Parse(Console.ReadLine());
                            Console.WriteLine("Ingrese los minutos");
                            minutos = Int32.Parse(Console.ReadLine());

                            for (h = 0; h < 1; h++)
                            {
                                if (hor >= encendido)
                                {
                                    Random generador = new Random();
                                    aleatorio = generador.Next(1, 100);



                                    for (i = 0; i < 1; i++)
                                    {
                                        if (aleatorio == 70)
                                        {
                                            Console.WriteLine("la temperatura esta en su nivel optimo");
                                            Console.WriteLine("La temperauta del exterior es: " + aleatorio);


                                        }
                                        else
                                        {
                                            if (aleatorio >= 70)
                                            {
                                                Console.WriteLine("La hora es " + hor + ":" + minutos);
                                                Console.WriteLine("La temperauta del exterior es: "+ aleatorio);
                                                Console.WriteLine("la temperatura esta muy alta de la desea");
                                                Console.WriteLine("la temperatura se nivelara al 70%");
                                            }
                                            else
                                            {
                                                if (aleatorio <= 70)
                                                {
                                                    Console.WriteLine("La hora es " + hor + ":" + minutos);
                                                    Console.WriteLine("La temperauta del exterior es: " + aleatorio);
                                                    Console.WriteLine("la temperatura esta muy baja de la desea");
                                                    Console.WriteLine("la temperatura se nivelara al 70%");
                                                }
                                            }
                                        }
                                    }

                                }
                                else
                                {
                                    if (hor < apagado)
                                    {
                                        Console.WriteLine(hor + ":" + minutos + "a esta hora la ventilacion esta apagada");
                                    }
                                }
                            }



                            Console.ReadKey();
                            goto menus;
                            break;
                        case 2:
                            Console.Clear();
                            int max;
                            int min;
                            int subir;
                            int bajar;
                            int grados;
                            int f = 0;
                            string habitacion;
                            Console.WriteLine("Bienvenido a la temperatura maxima y minima");
                            Console.WriteLine("Temperatura maxima desea es 22 y temperatura minima es 18");
                            Console.WriteLine("Ingrese temperatura máxima ");
                            max = int.Parse(Console.ReadLine());
                            Console.WriteLine("Ingrese temperatura mínima ");
                            min = int.Parse(Console.ReadLine());
                            Console.ReadKey();
                            Console.Clear();
                            Console.WriteLine("La temperatura máxima es: " + max);
                            Console.WriteLine("La temperatura mínima es: " + min);
                            Console.ReadKey();
                            Console.Clear();
                            Console.WriteLine("Ingrese la habitacion que se encuentra");
                            habitacion = Console.ReadLine();

                            Random random = new Random();
                            aleatorio = random.Next(1, 100);



                            int menu;
                            Console.Clear();
                            Console.WriteLine("       Entrara a la " + habitacion);
                            Console.WriteLine("       1. Si");
                            Console.WriteLine("       2. No");

                            menu = int.Parse(Console.ReadLine());

                            switch (menu)
                            {
                                case 1:
                                    Console.WriteLine("El radiador de la " + habitacion + " esta encendida");
                                    for (f = 0; f < 1; f++)
                                    {
                                        if (aleatorio == max)
                                        {
                                            Console.WriteLine("Los grados de la habitacion son " + aleatorio);
                                            Console.WriteLine("la temperatura es la deseada");
                                        }
                                        else
                                        {
                                            if (aleatorio >= max)
                                            {
                                                Console.WriteLine("Los grados de la habitacion son " + aleatorio);
                                                Console.WriteLine("la temperatura esta alta de la deseada");
                                                Console.WriteLine("La temperatura optima es " + max);
                                                Console.WriteLine("Bajar la temperatura a la optima");
                                                bajar = Int32.Parse(Console.ReadLine());

                                                if (bajar == max)
                                                {
                                                    Console.WriteLine("la temperatura es la deseada");
                                                }
                                                else
                                                {
                                                    if (aleatorio <= min)
                                                    {
                                                        Console.WriteLine("Los grados de la habitacion son " + aleatorio);
                                                        Console.WriteLine("la temperatura esta muy baja, no es la optima");
                                                        Console.WriteLine("La temperatura optima es "+min);
                                                        Console.WriteLine("subir la temperatura a la optima");
                                                        subir = Int32.Parse(Console.ReadLine());

                                                        if (subir == max)
                                                        {
                                                            Console.WriteLine("Los grados de la habitacion son " + aleatorio);

                                                            Console.WriteLine("la temperatura es la deseada");

                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    break;

                                case 2:
                                    Console.WriteLine("El radiador de la " + habitacion + " esta apagada");

                                    break;
                            }
                            Console.ReadKey();
                            goto menus;
                            break;
                        case 3:
                            Console.Clear();
                            double suma, todo, x, n, promedio;
                            string linea;
                            string habitacion1;
                            suma = 0;
                            Console.WriteLine("Cuantas habitaciones desea configurar:");
                            linea = Console.ReadLine();
                            n = int.Parse(linea);
                            Console.Clear();
                            for (x = 1; x <= n; x++)
                            {
                                Console.WriteLine("Ingresar la habitacion");
                                habitacion1 = Console.ReadLine();
                                Random rdm = new Random();
                                todo = rdm.Next(1, 100);
                                Console.WriteLine("La temperatura es: " + todo);
                                suma = suma + todo;
                            }

                            promedio = suma / n;
                            Console.WriteLine("El promedio es: " + promedio);
                            Console.ReadKey();
                            goto menus;
                            break;
                        case 4:
                            goto menu;
                            break;
                    }
                    break;
                case 5:
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Ingrese una opción válida entre 1 a 5");
                    break;
            }
            Console.ReadKey();
        }
    }
}
