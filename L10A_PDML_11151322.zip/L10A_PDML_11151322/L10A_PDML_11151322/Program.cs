﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10A_PDML_11151322
{
    internal class Program
    {
        public static bool Login(string login, string password) 
        {
            string Password;
            Password = password;
            string Login;
            Login = login;
            bool res = false;
            if (Login == "usuario1" && Password == "asdasd")
            {
                res = true;
            }
            return res;
        }



        static void Main(string[] args)
        {
            string login;
            string password;
            int cont = 1;
            while(cont < 4) 
            {
                Console.WriteLine("Ingrese usuario");
                login = (Console.ReadLine());
                Console.WriteLine("Ingrese contraseña");
                password = (Console.ReadLine());
                if (Login(login, password) == true)
                {
                    Console.WriteLine("Usuario correcto");
                    cont = 4;
                }
                if (Login(login, password) == false)
                {
                    Console.WriteLine("Intente nuevamente");
                } 
                cont++; 
            } if (cont == 4)
            {
                 Console.WriteLine("Ya no tiene intentos");
            }
            
            Console.ReadKey();
            
        }
           

        
    }
}
