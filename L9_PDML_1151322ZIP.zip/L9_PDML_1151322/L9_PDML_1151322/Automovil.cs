﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace L9_PDML_1151322
{
    internal class Automovil
    {
        private int modelo;
        private double precio;
        private string marca;
        private bool disponible;
        private double tipoCambioDolar;
        private double descuentoAplicado;

        public Automovil()
        {
            this.modelo = 2019;
            this.precio = 10000.00;
            this.marca = ("");
            this.disponible = false;
            this.tipoCambioDolar = 7.50;
            this.descuentoAplicado = 0.00;
        }

       public void setmodelo(int unModelo)
        {
            this.modelo = unModelo;
        }
        public void setprecio(double unPrecio)
        {
            this.precio = unPrecio;
        }
        public void setmarca(string unaMarca)
        {
            this.marca = unaMarca;
        }
        public void setTipocambio(double unTipoCambio)
        {
            this.tipoCambioDolar = unTipoCambio;
        }
        public void CambiarDisponibilidad()
        {
            if (this.disponible == true)
            {
                this.disponible = false;
            }
            else
            {
                this.disponible = true;
            }
        }
        public string MostrarDisponibilidad()
        {
            string result;
            if (this.disponible == true)
            {
                this.disponible = false;
                result = "Disponible";
            }
            else
            {
                this.disponible= false;
                result = "No se encuentra disponible actualmente";
            }
            return result;
        }
        public string MostrarInformacion()
        {
           // string marca;
           // string modelo;
           // string precio;
           // string calcularprecioendolares;
            string mensaje;
            mensaje = "Marca" + marca + "Modelo" + modelo + ". Precio de venta: Q" + precio + "Precion en dolares $" + tipoCambioDolar + "." + MostrarDisponibilidad();
            return mensaje;
        }

        public void AplicarDescuento(double descuento)
        {
            descuentoAplicado = descuento;
            precio = precio - descuentoAplicado;
        }
        internal void DefinirModelo(TextBox textboxA)
        {
            throw new NotImplementedException();
        }
    }

    internal static class Program
    {
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }   
}
