﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L9_PDML_1151322
{
    public partial class Form1 : Form
    {
        Automovil objautomovil = new Automovil();
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            objautomovil.setmodelo(int.Parse(textBox1.Text));
            objautomovil.setprecio(Convert.ToDouble(textBox2.Text));
            objautomovil.setmarca(textBox3.Text);
            objautomovil.setTipocambio(Convert.ToDouble(textBox4.Text));
            textBox6.Text = objautomovil.MostrarInformacion();
            button2.Enabled = true;
            button3.Enabled = true;
            tabControl1.SelectTab(tabPage2);
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            objautomovil.AplicarDescuento(Convert.ToDouble(textBox5.Text));
            textBox6.Text = objautomovil.MostrarInformacion();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            objautomovil.CambiarDisponibilidad();
            textBox6.Text = objautomovil.MostrarInformacion();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void fileSystemWatcher1_Changed(object sender, System.IO.FileSystemEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
