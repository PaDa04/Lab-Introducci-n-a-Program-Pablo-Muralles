﻿class program
{
  static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su nombre: ");
        string Nombre = Console.ReadLine(); 
        
        Console.WriteLine("Hola mundo");
        Console.WriteLine("soy " + Nombre);

        /* Console.Writeline muestra datos sin mostrar la nueva línea, mientras que la otra muestra los datos junto con la nueva muestra */

        Console.Write("Hola mundo");
        Console.Write(" soy " + Nombre);
        Console.ReadKey();
    }  

}


